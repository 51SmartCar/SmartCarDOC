//
//  CommanParameter.h
//  AoSmart
//
//  Created by rakwireless on 16/1/21.
//  Copyright © 2016年 rak. All rights reserved.
//

#ifndef CommanParameter_h
#define CommanParameter_h

#define diff_top  24
#define diff_bottom  20
#define diff_x  20
#define title_size  36
#define main_help_size  22
#define add_title_size  22
#define add_text_size  18
#define add_bg  242
#define diff_help_x 5
#define list_row_height 50
#define list_group_height 44

#endif /* CommanParameter_h */
