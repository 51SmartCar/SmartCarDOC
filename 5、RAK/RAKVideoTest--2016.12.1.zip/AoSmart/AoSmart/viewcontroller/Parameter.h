//
//  Parameter.h
//  AoSmart
//
//  Created by rakwireless on 16/1/21.
//  Copyright © 2016年 rak. All rights reserved.
//

#ifndef Parameter_h
#define Parameter_h

#define AddTitle 20

#endif /* Parameter_h */
