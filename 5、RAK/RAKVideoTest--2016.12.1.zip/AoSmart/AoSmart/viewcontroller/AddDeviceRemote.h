//
//  AddDeviceRemote.h
//  AoSmart
//
//  Created by rakwireless on 16/1/22.
//  Copyright © 2016年 rak. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddDeviceRemote : UIViewController
{
    UIButton *_AddDeviceRemoteBack;
    UILabel  *_AddDeviceRemoteTitle;
    UILabel  *_AddDeviceRemoteText;
    UILabel  *_AddDeviceRemoteNote;
    UITextField *_AddDeviceRemoteIDField;
    UITextField *_AddDeviceRemoteNameField;
    UIButton *_AddDeviceRemoteBtn;
}
@end
