//
//  DeviceConnectFailed.h
//  AoSmart
//
//  Created by rakwireless on 16/1/26.
//  Copyright © 2016年 rak. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DeviceConnectFailed : UIViewController
{
    UIButton *_DeviceConnectFailedBack;
    UIImageView *_DeviceConnectFailedImage;
    UILabel *_DeviceConnectFailedText;
}
@end
