//
//  VideoHelp.h
//  AoSmart
//
//  Created by rakwireless on 16/1/25.
//  Copyright © 2016年 rak. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VideoHelp : UIViewController
{
    UIButton *_videoHelpBack;
    UILabel  *_videoHelpTitle;
    UILabel  *_videoHelp1;
    UIButton  *_videoHelpAndroid;
    UILabel  *_videoHelp2;
    UIButton  *_videoHelpIOS;
    UILabel  *_videoHelp3;
    UILabel  *_videoHelp4;
    UILabel  *_videoHelp5;
    UILabel  *_videoHelp6;
    UILabel  *_videoHelp7;
    UILabel  *_videoHelp8;
}
@end
