//
//  AddDeviceFailed.h
//  AoSmart
//
//  Created by rakwireless on 16/1/23.
//  Copyright © 2016年 rak. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddDeviceFailed : UIViewController
{
    UIButton *_AddDeviceFailedBack;
    UIImageView *_AddDeviceFailedImage;
    UILabel *_AddDeviceFailedText;
    UIButton *_AddDeviceFailedEasy;
    UIButton *_AddDeviceFailedAP;
}
@end
