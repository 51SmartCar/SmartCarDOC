//
//  AddDeviceStep3AP.h
//  AoSmart
//
//  Created by rakwireless on 16/2/28.
//  Copyright © 2016年 rak. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddDeviceStep3AP : UIViewController
{
    UIButton *_AddDeviceStep3APBack;
    UILabel  *_AddDeviceStep3APTitle;
    UILabel  *_AddDeviceStep3APText;
    UILabel  *_AddDeviceStep3APNote;
    UIButton *_AddDeviceStep3APNext;
}
@end
