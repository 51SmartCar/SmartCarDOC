//
//  AlbumDelegateProxy.m
//  camSight
//
//  Created by rakwireless on 16/8/4.
//  Copyright © 2016年 rak. All rights reserved.
//

#import "AlbumDelegateProxy.h"

@implementation AlbumDelegateProxy

- (id)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

@end
