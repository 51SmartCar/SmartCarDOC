//
//  PlayVideoViewController.h
//  Feishen
//
//  Created by rakwireless on 15/12/22.
//  Copyright © 2015年 rak. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlayVideoViewController : UIViewController{
    UIButton* playVideoBack;
}
@property(nonatomic) NSString *Videourl;
@end
