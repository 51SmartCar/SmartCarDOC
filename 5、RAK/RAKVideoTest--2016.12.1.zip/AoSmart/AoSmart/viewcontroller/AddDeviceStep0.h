//
//  AddDeviceStep0.h
//  AoSmart
//
//  Created by rakwireless on 16/1/21.
//  Copyright © 2016年 rak. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddDeviceStep0 : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    UIButton *_AddDeviceStep0Back;
    UILabel  *_AddDeviceStep0Title;
    UITableView *_AddDeviceStep0Table;
}
@end
