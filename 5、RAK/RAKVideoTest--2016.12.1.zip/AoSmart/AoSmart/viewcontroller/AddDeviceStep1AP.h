//
//  AddDeviceStep1AP.h
//  AoSmart
//
//  Created by rakwireless on 16/2/26.
//  Copyright © 2016年 rak. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddDeviceStep1AP : UIViewController
{
    UIButton *_AddDeviceStep1APBack;
    UILabel  *_AddDeviceStep1APTitle;
    UILabel  *_AddDeviceStep1APText;
    UILabel  *_AddDeviceStep1APNote;
    UIButton *_AddDeviceStep1APNext;
    UIImageView *_AddDeviceStep1APDevice;
    UIImageView *_AddDeviceStep1APDevice1;
    UIImageView *_AddDeviceStep1APDevice2;
    UIButton *_AddDeviceStep1APDevice1Btn;
    UIButton *_AddDeviceStep1APDevice2Btn;
    UILabel *_AddDeviceStep1APDevice1Text;
    UILabel *_AddDeviceStep1APDevice2Text;
}
@end
