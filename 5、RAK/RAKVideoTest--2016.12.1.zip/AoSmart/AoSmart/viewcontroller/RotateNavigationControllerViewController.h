//
//  RotateNavigationControllerViewController.h
//  CloudCompanion
//
//  Created by liweixiang on 15-1-22.
//  Copyright (c) 2015年 rak. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RotateNavigationControllerViewController : UINavigationController

@end
