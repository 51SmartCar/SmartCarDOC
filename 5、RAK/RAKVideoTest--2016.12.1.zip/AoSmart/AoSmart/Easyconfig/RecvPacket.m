//
//  RecvPacket.m
//  EasyConfig
//
//  Created by wei-mac on 14-4-9.
//  Copyright (c) 2014年 cz. All rights reserved.
//

#import "RecvPacket.h"

@implementation RecvPacket

@end
