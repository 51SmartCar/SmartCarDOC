//
//  RecvPacket.h
//  EasyConfig
//
//  Created by wei-mac on 14-4-9.
//  Copyright (c) 2014年 cz. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RecvPacket : NSObject
@property (nonatomic)NSString *module_id;
@property (nonatomic)NSString *module_ip;
@end
