#include <stc12c5a60s2.h>
sbit  DJ1 = P1 ^ 0;
sbit  DJ2 = P1 ^ 1;
unsigned int DJ1_Value=0;
unsigned int DJ2_Value=0;


void Delay_Ms(unsigned int a)
{
		unsigned int i;
	 while(--a!=0)
	 {
			for(i=0;i<600;i++)
		  {
					;
			}
	 }
}
void IO_Init()
{
	P1M0 = 0X03;
	P1M1 = 0X00;  //����P1.0 P1.1 Ϊ�������
}

void Timer_init()
{
	AUXR|=0X00;   //T0 T0������12T
	TMOD |=0X11;  //T0�����ڷ�ʽ1  16λ
	ET0 = 1;     //��ʱ��0  �жϿ���
	EA = 1;  //�ж��ܿ��� 
}

void Timer0(unsigned int us)
{
	unsigned int value;
	value = 0xfffff-us;
	TH0 = value>>8;
	TL0 = (value<<8)>>8;
	TR0 = 1;
}
void main()
{
	IO_Init();
	Timer_init();
	Timer0(100);
	while(1)
	{
		DJ1_Value = 500;
		DJ2_Value = 2500;
    Delay_Ms(1000);
    DJ1_Value = 2500; 
		DJ2_Value = 500;
    Delay_Ms(1000);		
	}
}

void  T0(void)   interrupt   1
{
		static unsigned char i=1;
	  switch(i)
				{
					case 1:
					{
						DJ1 = 1;
						Timer0( DJ1_Value);
					}  break;
					case 2:
					{
						DJ1 = 0;
						Timer0(2500-DJ1_Value);
					} break;
					case 3:
					{
						DJ2 = 1;
						Timer0(DJ2_Value);
					}break;
					case 4:
					{
						DJ2 = 0;
						Timer0(2500-DJ2_Value);
					}break;
					case 5:
					{
						Timer0(2500);
					}break;
			   	case 6:
					{
						Timer0(2500);
					}break;
					case 7:
					{
						Timer0(2500);
					}break;
					case 8:
					{
						Timer0(2500);
					}break;
				  case 9:
					{
						Timer0(2500);
						i=0;
					}break;
					default:break;
				}
		i++;
}