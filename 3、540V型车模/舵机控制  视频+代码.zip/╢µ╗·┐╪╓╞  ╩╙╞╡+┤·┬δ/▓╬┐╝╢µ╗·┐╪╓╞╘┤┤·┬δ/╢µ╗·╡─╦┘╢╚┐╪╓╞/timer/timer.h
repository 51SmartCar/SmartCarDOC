#ifndef TIMER
#define TIMER
extern Timer_init();
extern Timer0(uint32 us);
#endif
