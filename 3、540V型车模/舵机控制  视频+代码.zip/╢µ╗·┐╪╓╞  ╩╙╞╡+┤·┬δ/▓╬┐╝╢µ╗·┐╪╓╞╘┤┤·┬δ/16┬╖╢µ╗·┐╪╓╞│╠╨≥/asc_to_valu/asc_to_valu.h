#ifndef ASC_TO_VALU
#define ASC_TO_VALU
extern uint8 ASC_To_Valu(uint8 asc);
extern void Valu_to_ASC(uint16 valu,uint8 *asc);
#endif
