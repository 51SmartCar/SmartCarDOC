#ifndef TIMER
#define TIMER
extern Timer_init();
extern Timer0(uint32 us);
extern Timer1(uint32 us);
extern Timer2(uint32 us);
extern Timer3(uint32 us);
#endif
